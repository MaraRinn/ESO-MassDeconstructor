-- sentry to make sure HWS is declared before use
if MD == nil then MD = {} end

--
-- Register with LibMenu and ESO
--
function MD.MakeMenu()
  -- load the settings->addons menu library
  local menu = LibStub("LibAddonMenu-2.0")
  local set = MD.settings

  -- the panel for the addons menu
  local panel = {
    type = "panel",
    name = "Mass Deconstructor",
    displayName = "Mass Deconstructor",
    author = "Ahmet `Amad` Ertem",
    version = "1.0",
  }

  -- this addons entries in the addon menu
  local options = {
    [1] = {
      type = "checkbox",
      name = "Deconstruct items in bank",
      getFunc = function() return set.BankMode end,
      setFunc = function(value)
        set.BankMode = value    
      end,
    },
    [2] = {
      type = "checkbox",
      name = "Deconstruct bound items",
      getFunc = function() return set.DeconstructBound end,
      setFunc = function(value)
        set.DeconstructBound = value
      end,
    },
    [3] = {
      type = "checkbox",
      name = "Deconstruct ornate items",
      getFunc = function() return set.DeconstructOrnate end,
      setFunc = function(value)
        set.DeconstructOrnate = value
      end,
    },
    [4] = {
      type = "slider",
      name = "Maximum item quality to deconstruct",
      tooltip = "Maximum quality below which items will be destroyed (1 = white,5=legendary)",
      min = 1, 
      max = 5, 
      getFunc = function() return set.maxQuality end,
      setFunc = function( maxQuality ) set.maxQuality = maxQuality end,
    },
  }

  menu:RegisterAddonPanel("MassDeconstructor", panel)
  menu:RegisterOptionControls("MassDeconstructor", options)
end