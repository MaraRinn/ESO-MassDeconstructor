local wm = GetWindowManager()
local em = GetEventManager()
local _

if MD == nil then MD = {} end


MD.name = "MassDeconstructor"
MD.version = "1.0"
MD.isDebug = false

MD.settings = {}


MD.isStation = 0
MD.totalDeconstruct = 0
MD.currentList = {}
MD.workFunc = nil

MD.defaults = {
  DeconstructOrnate = false,
  DeconstructBound = false,
  BankMode = false,
  maxQuality = 4,
}

MD.Inventory = {
  items = { },
  clothier = { },
  blacksmith = { },
  enchanter = { },
  woodworker = { },
}




local function IsItemProtected(bagId, slotId)
  --Item Saver support
  if ItemSaver_IsItemSaved and ItemSaver_IsItemSaved(bagId, slotId) then
    return true
  end

  --FCO ItemSaver support
  if FCOIsMarked and FCOIsMarked(GetItemInstanceId(bagId, slotId), {1,2,3,4,5,6,7,8,10,11,12}) then -- 9 is deconstruct
    return true
  end

  --FilterIt support
  if FilterIt and FilterIt.AccountSavedVariables and FilterIt.AccountSavedVariables.FilteredItems then
    local sUniqueId = Id64ToString(GetItemUniqueId(bagId, slotId))
    if FilterIt.AccountSavedVariables.FilteredItems[sUniqueId] then
      return FilterIt.AccountSavedVariables.FilteredItems[sUniqueId] ~= FILTERIT_VENDOR
    end
  end

  return false
end

function MD:GetArmorType(bagId,slotId)
  local icon = GetItemInfo(bagId,slotId)
  if (string.find(icon, "heavy")) then
    return ARMORTYPE_HEAVY
  elseif string.find(icon,"medium") then
    return ARMORTYPE_MEDIUM
  elseif string.find(icon,"light") then
    return ARMORTYPE_LIGHT
  else
    return ARMORTYPE_NONE
  end
end


function MD:GetWeaponType(bagId,slotId)

  local icon = GetItemInfo(bagId,slotId)

  if (string.find(icon, "1hsword")) then
    return WEAPONTYPE_SWORD
  elseif string.find(icon,"2hsword") then
    return WEAPONTYPE_TWO_HANDED_SWORD
  elseif string.find(icon,"1haxe") then
    return WEAPONTYPE_AXE
  elseif string.find(icon,"2haxe") then
    return WEAPONTYPE_TWO_HANDED_AXE
  elseif string.find(icon,"1hhammer") then
    return WEAPONTYPE_HAMMER
  elseif string.find(icon,"2hhammer") then
    return WEAPONTYPE_TWO_HANDED_HAMMER
  elseif string.find(icon,"dagger") then
    return WEAPONTYPE_DAGGER
  elseif string.find(icon,"shield") then
    return WEAPONTYPE_SHIELD
  elseif string.find(icon,"bow") then
    return WEAPONTYPE_BOW
  elseif string.find(icon,"staff") then
    return WEAPONTYPE_FIRE_STAFF
  else
    return WEAPONTYPE_NONE
  end
end


function MD:IsOrnate(bagId,slotId)
  return GetItemTrait(bagId,slotId) == ITEM_TRAIT_TYPE_ARMOR_ORNATE or GetItemTrait(bagId,slotId) == ITEM_TRAIT_TYPE_WEAPON_ORNATE
end

function MD:IsMaterial(bagId,slotId)
  return GetItemType(bagId,slotId) == ITEMTYPE_BLACKSMITHING_MATERIAL
  or GetItemType(bagId,slotId) == ITEMTYPE_WOODWORKING_MATERIAL
  or GetItemType(bagId,slotId) == ITEMTYPE_CLOTHIER_MATERIAL
  or GetItemType(bagId,slotId) == ITEMTYPE_ENCHANTING_RUNE
end

function MD:IsRawMaterial(bagId,slotId)
  return GetItemType(bagId,slotId) == ITEMTYPE_BLACKSMITHING_RAW_MATERIAL
  or GetItemType(bagId,slotId) == ITEMTYPE_WOODWORKING_RAW_MATERIAL
  or GetItemType(bagId,slotId) == ITEMTYPE_CLOTHIER_RAW_MATERIAL
end

function MD:GetQuality(bagId,slotId)
  local _,_,_,_,_,_,_,qual = GetItemInfo(bagId,slotId)
  return qual
end

function MD:isItemBindable(bagId, slotIndex)
  local itemLink = GetItemLink(bagId, slotIndex)
  if itemLink then
    --Bound
    if(IsItemLinkBound(itemLink)) then
      --Item is already bound
      return 1
    else
      local bindType = GetItemLinkBindType(itemLink)
      if(bindType ~= BIND_TYPE_NONE and bindType ~= BIND_TYPE_UNSET) then
        --Item can still be bound
        return 2
      else
        --Item is already bound or got no bind type
        return 3
      end
    end
  else
    return 0
  end
end

function MD.addStuffToInventoryForBag(bagId)
  local GetItemType = GetItemType
  local GetItemInfo = GetItemInfo
  local GetAlchemyItemTraits = GetAlchemyItemTraits
  local zo_strformat = zo_strformat
  local GetItemName = GetItemName
  local GetItemLevel = GetItemLevel
  local bagSlots = GetBagSize(bagId) -1

  for slotIndex = 0, bagSlots do
    local itemType = GetItemType(bagId, slotIndex)
    local tradeSkillType = GetItemCraftingInfo(bagId, slotIndex)
    local GetArmorType = MD:GetArmorType(bagId,slotIndex)
    local GetWeaponType = MD:GetWeaponType(bagId,slotIndex)
    local _, stack, _, _, _, _, _, quality = GetItemInfo(bagId, slotIndex)
    local name = GetItemName(bagId, slotIndex)
    local continue_ = true
    local level = GetItemLevel(bagId, slotIndex)
    local itemLink = GetItemLink(bagId, slotIndex)

    boundType = 0
    local isProtected = IsItemProtected(bagId, slotIndex)
    local isOrnated = MD:IsOrnate(bagId, slotIndex)
    boundType = MD:isItemBindable(bagId, slotIndex)
    local bagCount, bankCount = GetItemLinkStacks(itemLink)
    -- is protected skip
    if continue_ then 
      if isProtected then
        continue_ = false
      end 
    end 

    -- check settings and skip ornate
    if continue_ then 
      if not MD.settings.DeconstructOrnate then
        if isOrnated then
          continue_ = false
        end
      end
    end

    -- check settings and skip if bounded
    if continue_ then
      if not MD.settings.DeconstructBound then
        if boundType == 1 then
          continue_ = false
        end
      end
    end

    -- check settings maxQuality and skip if greater
    if continue_ then
      if quality > MD.settings.maxQuality then
        continue_ = false
      end
    end

    -- if material break
    if continue_ then 
      if MD:IsMaterial(bagId, slotIndex) then
        continue_ = false
      end
    end 

    -- if raw material break
    if continue_ then 
      if MD:IsRawMaterial(bagId, slotIndex) then
        continue_ = false
      end
    end 

    if continue_ then
      if itemType ~= ITEMTYPE_ARMOR and itemType ~= ITEMTYPE_WEAPON and itemType ~= ITEMTYPE_GLYPH_ARMOR and itemType ~= ITEMTYPE_GLYPH_JEWELRY and itemType ~= ITEMTYPE_GLYPH_WEAPON then
        continue_ = false
      end
    end

    if continue_ then
      name = zo_strformat(SI_TOOLTIP_ITEM_NAME, name)
      if not true then
        d(name.."-"..itemLink.."-"..stack.."-"..bagCount.."-"..bankCount)
        --  d(quality)
        --d(boundType)
        d("|caaaaaa-----------|r")
      end

      n = {}
      n.bagId = bagId
      n.slotIndex = slotIndex
      n.stack = bagCount + bankCount

      if (itemType == ITEMTYPE_ARMOR and (GetArmorType == ARMORTYPE_MEDIUM or GetArmorType == ARMORTYPE_LIGHT)) then
        --if(tradeSkillType == CRAFTING_TYPE_CLOTHIER) then
        if MD.Inventory.clothier[itemLink] == nil then
          MD.Inventory.clothier[itemLink] = n
        end
      elseif ((itemType == ITEMTYPE_ARMOR and GetArmorType == ARMORTYPE_HEAVY) or GetWeaponType == WEAPONTYPE_SWORD or  GetWeaponType == WEAPONTYPE_TWO_HANDED_SWORD or  GetWeaponType == WEAPONTYPE_AXE or  GetWeaponType == WEAPONTYPE_TWO_HANDED_AXE or  GetWeaponType == WEAPONTYPE_HAMMER or  GetWeaponType == WEAPONTYPE_DAGGER or GetWeaponType == WEAPONTYPE_TWO_HANDED_HAMMER  )  then
        if MD.Inventory.blacksmith[itemLink] == nil then
          MD.Inventory.blacksmith[itemLink] = n
        end
      elseif (GetWeaponType == WEAPONTYPE_BOW or GetWeaponType == WEAPONTYPE_FIRE_STAFF or GetWeaponType == WEAPONTYPE_FROST_STAFF or GetWeaponType == WEAPONTYPE_HEALING_STAFF or GetWeaponType == WEAPONTYPE_LIGHTNING_STAFF or GetWeaponType == WEAPONTYPE_SHIELD) then
        if MD.Inventory.woodworker[itemLink] == nil then
          MD.Inventory.woodworker[itemLink] = n
        end
      elseif itemType == ITEMTYPE_GLYPH_ARMOR or itemType == ITEMTYPE_GLYPH_JEWELRY or itemType == ITEMTYPE_GLYPH_WEAPON then
        if MD.Inventory.enchanter[itemLink] == nil then
          MD.Inventory.enchanter[itemLink] = n
        end
      end
      --   end
    end
  end
end

function MD.yazbakem() 
  MD.setList()

  for itemLink, tablosu in pairs(MD.currentList) do
    --local name = GetItemName(tablosu.bagId, tablosu.slotIndex)
    --name = zo_strformat(SI_TOOLTIP_ITEM_NAME, name)
    d("|cff0000Deconstructable:|r "..itemLink)
  end

end

function MD.setList()
  if MD.isStation == 1 then
    MD.currentList = MD.Inventory.clothier
  elseif MD.isStation == 2 then
    MD.currentList = MD.Inventory.blacksmith
  elseif MD.isStation == 3 then
    MD.currentList = MD.Inventory.woodworker
  elseif MD.isStation == 4 then
    MD.currentList = MD.Inventory.enchanter
  end
end  

function MD.isInWorkstationandTab() 
  if(MD.isStation == 0) then
    --d("|cff0000You're not at crafting station|r")
    return false
  end
  if MD.isStation == 4 then
    if ENCHANTING.enchantingMode ~= ENCHANTING_MODE_EXTRACTION then
      --d("|cff0000You must be at extraction tab|r")
      -- return false
    end
  else
    if SMITHING.mode ~= SMITHING_MODE_DECONSTRUCTION  then
      --d("|cff0000You must be at deconstruction tab|r")
      --return false
    end
  end
  return true
end

function MD.startDeconsruction() 

  if not MD.isInWorkstationandTab() then
    return
  end

  -- : station = 4 == enchanter
  if MD.isStation == 4 then
    if ENCHANTING.enchantingMode ~= ENCHANTING_MODE_EXTRACTION then
      ENCHANTING:SetEnchantingMode(ENCHANTING_MODE_EXTRACTION)
    end
  else
    if SMITHING.mode ~= SMITHING_MODE_DECONSTRUCTION then
      SMITHING:SetMode(SMITHING_MODE_DECONSTRUCTION)
    end
  end

  -- : refrest list for getting count
  MD.setList()


  -- : reset counter
  MD.totalDeconstruct = 0
  for itemLink, tablosu in pairs( MD.currentList ) do
    MD.totalDeconstruct = MD.totalDeconstruct + tablosu.stack
  end
  d("Destructable item count: |cff0000"..(MD.totalDeconstruct).."|r")
  MD.ContinueWork()
end

function MD.ContinueWork()
  MD.updateStuffofInventory()
  MD.setList()
  EVENT_MANAGER:UnregisterForEvent(MD.name, EVENT_CRAFT_COMPLETED)
  if MD.totalDeconstruct > 0 then
    --if MD.isStation == 1 then
    --d(MD.currentList )
    for itemLink, tablosu in pairs( MD.currentList ) do

      --d(tablosu.bagId)
      --d(tablosu.slotIndex)
      if MD.isStation == 4 then
        -- ENCHANTING:AddItemToCraft(tablosu.bagId, tablosu.slotIndex)
        --SMITHING.refinementPanel:Extract()
        ExtractEnchantingItem(tablosu.bagId, tablosu.slotIndex)
      else 
        SMITHING:AddItemToCraft(tablosu.bagId, tablosu.slotIndex)
        SMITHING.deconstructionPanel:Extract()
      end
      MD.totalDeconstruct = MD.totalDeconstruct - 1

      if true then
        EVENT_MANAGER:RegisterForEvent(MD.name, EVENT_CRAFT_COMPLETED, function() 
            MD.ContinueWork() 
          end)
      end
      break
    end
    --end
  else

  end
end

function MD.updateStuffofInventory()
  MD.Inventory = {
    items = { },
    clothier = { },
    blacksmith = { },
    enchanter = { },
    woodworker = { },
  }

  MD.addStuffToInventoryForBag(BAG_BACKPACK)
  -- bank
  if MD.settings.BankMode then MD.addStuffToInventoryForBag(BAG_BANK) end

end

function MD:OnCrafting(sameStation)
  MD.updateStuffofInventory() 
  if MD.isDebug then
    if MD.isStation == 1 then
      d("MD Clothier")
    elseif MD.isStation == 2 then
      d("MD Blacksmith")
    elseif MD.isStation == 3 then
      d("MD Woodworker")
    elseif MD.isStation == 4 then
      d("MD Enchanter")
    end

  end
  KEYBIND_STRIP:AddKeybindButtonGroup(MD.KeybindStripDescriptor)
  KEYBIND_STRIP:UpdateKeybindButtonGroup(MD.KeybindStripDescriptor)
  if(MD.isStation > 0 and MD.isStation < 5) then
    MD:yazbakem(MD.isStation)
  end
end

function MD:OnCraftEnd()
  MD.isStation = 0
  if MD.isDebug then
    d("MD station leave")
  end
  KEYBIND_STRIP:RemoveKeybindButtonGroup(MD.KeybindStripDescriptor)
end


local function processSlashCommands(option)	
  local options = {}
  local searchResult = { string.match(option,"^(%S*)%s*(.-)$") }
  for i,v in pairs(searchResult) do
    if (v ~= nil and v ~= "") then
      options[i] = string.lower(v)
    end
  end

  if options[1] == "mk" then
    MD.updateStuffofInventory() 
  elseif options[1] == "c" then
    MD.yazbakem(0)
  elseif options[1] == "test" then
    MD.test()
  end


end


function MD.test ()
  for item in pairs(MD.Inventory.clothier) do
    -- ZO_SharedSmithingExtraction:SetExtractionSlotItem(1
  end

end

function MD:registerEvents()

  EVENT_MANAGER:RegisterForEvent(MD.name, EVENT_CRAFTING_STATION_INTERACT, function(eventCode, craftSkill, sameStation)
      if craftSkill == CRAFTING_TYPE_CLOTHIER then
        MD.isStation = 1
      elseif craftSkill == CRAFTING_TYPE_BLACKSMITHING then
        MD.isStation = 2
      elseif craftSkill == CRAFTING_TYPE_WOODWORKING then
        MD.isStation = 3
      elseif craftSkill == CRAFTING_TYPE_ENCHANTING then
        MD.isStation = 4
      end 
      MD:OnCrafting(sameStation)
    end)

  EVENT_MANAGER:RegisterForEvent(MD.name, EVENT_END_CRAFTING_STATION_INTERACT, function(eventCode) 
      if MD.isStation > 0 then
        MD:OnCraftEnd() 
      end
    end)

end

--
-- This function that will initialize our addon with ESO
--
function MD.Initialize(event, addon)
  -- filter for just HWS addon event
  if addon ~= MD.name then return end
  SLASH_COMMANDS["/md"] = processSlashCommands

  em:UnregisterForEvent("MassDeconstructorInitialize", EVENT_ADD_ON_LOADED)
  MD:registerEvents()
  -- load our saved variables
  MD.settings = ZO_SavedVars:New("MassDeconstructorSavedVars", 1, nil, MD.defaults)

  -- make a label for our keybinding
  ZO_CreateStringId("SI_BINDING_NAME_MD_DECONSTRUCTOR_DECON_ALL", "Mass Deconstruct")

  -- make our options menu
  MD.MakeMenu()
  MD.KeybindStripDescriptor =
  {
    { -- I think you can have more than one button in your group if you add more of these sub-groups
      name = GetString(SI_BINDING_NAME_MD_DECONSTRUCTOR_DECON_ALL),
      keybind = "MD_DECONSTRUCTOR_DECON_ALL",
      callback = function() MD.startDeconsruction() end,
      visible = function() return true or MD.isInWorkstationandTab()  end,
    },
    alignment = KEYBIND_STRIP_ALIGN_CENTER,
  }

end


-- register our event handler function to be called to do initialization
em:RegisterForEvent(MD.name, EVENT_ADD_ON_LOADED, function(...) MD.Initialize(...) end)
